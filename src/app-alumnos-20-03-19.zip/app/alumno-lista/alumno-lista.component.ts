import { Component, OnInit } from '@angular/core';
import { Alumno } from '../alumno/Alumno';

@Component({
  selector: 'app-alumno-lista',
  templateUrl: './alumno-lista.component.html',
  styleUrls: ['./alumno-lista.component.css']
})
export class AlumnoListaComponent implements OnInit {

  alumnos: Alumno[] = [
    {
      id: 1,
      nombre: 'Alicia',
      edad: 23,
      calificacion: 85,
      carrera: 'ISC',
      sexo: 'F'
    },
    {
      id: 2,
      nombre: 'Alberto',
      edad: 24,
      calificacion: 50,
      carrera: 'ISC',
      sexo: 'M'
    }
  ];

  constructor() { }

  ngOnInit() {
  }

  editarAlumno(alumnoEditar){
    console.log(`El alumno a editar es ${alumnoEditar.id} nombre: ${alumnoEditar.nombre}` );
  }
}
