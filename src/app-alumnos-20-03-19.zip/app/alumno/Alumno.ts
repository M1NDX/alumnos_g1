export class Alumno {
    id: number;
    nombre: string;
    edad: number;
    calificacion: number;
    carrera: string;
    sexo: string;
  }
