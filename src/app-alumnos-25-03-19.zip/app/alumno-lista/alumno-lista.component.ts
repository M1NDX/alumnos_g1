import { Component, OnInit } from '@angular/core';
import { Alumno } from '../alumno/Alumno';
import { AlumnosService } from '../alumnos.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-alumno-lista',
  templateUrl: './alumno-lista.component.html',
  styleUrls: ['./alumno-lista.component.css']
})
export class AlumnoListaComponent implements OnInit {

  alumnos: Alumno[];
  private subscript: Subscription;

  constructor(private alumnosService: AlumnosService ) { }

  ngOnInit() {
    this.alumnos = this.alumnosService.getAlumnos();

    this.subscript = this.alumnosService.cambiaDato
      .subscribe(
        (arregloAlumnos: Alumno[]) => {
           this.alumnos = arregloAlumnos;
        }
      );

  }

  editarAlumno(alumnoEditar){
    console.log(`El alumno a editar es ${alumnoEditar.id} nombre: ${alumnoEditar.nombre}` );
  }

  borrarAlumnoLista(alumnoABorrar) {
    this.alumnosService.borrarAlumno(alumnoABorrar.id);
    //this.alumnos = this.alumnosService.getAlumnos();
  }

}
