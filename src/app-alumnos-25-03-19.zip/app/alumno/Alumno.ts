export class Alumno {
  constructor(
    public id: number,
    public nombre: string,
    public edad: number,
    public calificacion: number,
    public carrera: string,
    public sexo: string
  ){}
  }
