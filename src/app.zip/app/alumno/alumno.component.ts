import { Component, OnInit } from '@angular/core';
import { Alumno } from './Alumno';


@Component({
  selector: 'app-alumno',
  templateUrl: './alumno.component.html',
  styleUrls: ['./alumno.component.css']
})
export class AlumnoComponent implements OnInit {
  
  alumno: Alumno = {
    id: 1,
    nombre: 'Alicia',
    edad: 23,
    calificacion: 85,
    carrera: 'ISC',
    sexo: 'F'
  };

  constructor() { }

  ngOnInit() {
  }

  alumnoPorBorrar() {
    console.log('Alumno a borrar ' + this.alumno.nombre);
  }


}
